# 1. Preparación del entorno

Assigned To: Yoseth Rivera
Status: Not started