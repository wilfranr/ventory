# 🔗 Sección de Contratos de API / Comunicación

[**Endpoints expuestos por el backend**](%F0%9F%94%97%20Seccio%CC%81n%20de%20Contratos%20de%20API%20Comunicacio%CC%81n%202069647e8710800fa800d1e55af4db09/Endpoints%20expuestos%20por%20el%20backend%202069647e871080cf9cf9c2cd8769cf42.md)

[**Ejemplos de peticiones/respuestas**](%F0%9F%94%97%20Seccio%CC%81n%20de%20Contratos%20de%20API%20Comunicacio%CC%81n%202069647e8710800fa800d1e55af4db09/Ejemplos%20de%20peticiones%20respuestas%202069647e871080b89321cd04cd933f20.md)

[**Manejo de errores**](%F0%9F%94%97%20Seccio%CC%81n%20de%20Contratos%20de%20API%20Comunicacio%CC%81n%202069647e8710800fa800d1e55af4db09/Manejo%20de%20errores%202069647e87108088a740da665de04945.md)

[**Autenticación y autorización entre front y back**](%F0%9F%94%97%20Seccio%CC%81n%20de%20Contratos%20de%20API%20Comunicacio%CC%81n%202069647e8710800fa800d1e55af4db09/Autenticacio%CC%81n%20y%20autorizacio%CC%81n%20entre%20front%20y%20back%202069647e8710803c932dd511abc277c9.md)

[**Versionado de API**](%F0%9F%94%97%20Seccio%CC%81n%20de%20Contratos%20de%20API%20Comunicacio%CC%81n%202069647e8710800fa800d1e55af4db09/Versionado%20de%20API%202069647e871080b88edac2e79da6e5a6.md)