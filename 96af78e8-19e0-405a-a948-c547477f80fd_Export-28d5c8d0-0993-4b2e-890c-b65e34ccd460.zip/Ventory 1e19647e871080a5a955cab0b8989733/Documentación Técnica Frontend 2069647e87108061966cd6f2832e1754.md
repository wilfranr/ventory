# Documentación Técnica Frontend

[Introducción](Documentacio%CC%81n%20Te%CC%81cnica%20Frontend%202069647e87108061966cd6f2832e1754/Introduccio%CC%81n%202069647e87108047b63dc9bff7fc75dc.md)

[**Stack tecnológico**](Documentacio%CC%81n%20Te%CC%81cnica%20Frontend%202069647e87108061966cd6f2832e1754/Stack%20tecnolo%CC%81gico%202069647e871080eb8e82c865a2ec63d5.md)

[**Estructura de carpetas/proyecto**](Documentacio%CC%81n%20Te%CC%81cnica%20Frontend%202069647e87108061966cd6f2832e1754/Estructura%20de%20carpetas%20proyecto%202069647e871080d3ab76dc9e02086ff7.md)

[**Guía de componentes**](Documentacio%CC%81n%20Te%CC%81cnica%20Frontend%202069647e87108061966cd6f2832e1754/Gui%CC%81a%20de%20componentes%202069647e871080a1b883de018f9f7825.md)

[**Consumo de APIs**](Documentacio%CC%81n%20Te%CC%81cnica%20Frontend%202069647e87108061966cd6f2832e1754/Consumo%20de%20APIs%202069647e87108035bf7fdb1d8d9b353e.md)

[**Gestión de estado**](Documentacio%CC%81n%20Te%CC%81cnica%20Frontend%202069647e87108061966cd6f2832e1754/Gestio%CC%81n%20de%20estado%202069647e87108098af25eae9cf4f723d.md)

[**Estilos y temas (Tailwind, PrimeNG, etc.)**](Documentacio%CC%81n%20Te%CC%81cnica%20Frontend%202069647e87108061966cd6f2832e1754/Estilos%20y%20temas%20(Tailwind,%20PrimeNG,%20etc%20)%202069647e8710808c801ffad74aedde35.md)

[**Routing y navegación**](Documentacio%CC%81n%20Te%CC%81cnica%20Frontend%202069647e87108061966cd6f2832e1754/Routing%20y%20navegacio%CC%81n%202069647e87108099ab9af5c2caf34e7e.md)

[**Internacionalización**](Documentacio%CC%81n%20Te%CC%81cnica%20Frontend%202069647e87108061966cd6f2832e1754/Internacionalizacio%CC%81n%202069647e871080139fb3f04545b6aa90.md)

[Testing y pruebas](Documentacio%CC%81n%20Te%CC%81cnica%20Frontend%202069647e87108061966cd6f2832e1754/Testing%20y%20pruebas%202069647e871080979510d1779c621566.md)

[**Guías de buenas prácticas**](Documentacio%CC%81n%20Te%CC%81cnica%20Frontend%202069647e87108061966cd6f2832e1754/Gui%CC%81as%20de%20buenas%20pra%CC%81cticas%202069647e871080e19044f5f342dd1226.md)

[**FAQ del Frontend**](Documentacio%CC%81n%20Te%CC%81cnica%20Frontend%202069647e87108061966cd6f2832e1754/FAQ%20del%20Frontend%202069647e8710807a9f2eceab8ab4f8cd.md)

[**Changelog / Historial de cambios**](Documentacio%CC%81n%20Te%CC%81cnica%20Frontend%202069647e87108061966cd6f2832e1754/Changelog%20Historial%20de%20cambios%202069647e87108084945bf6fda96c93f7.md)