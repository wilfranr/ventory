# 🚀 DevOps / CI/CD / Infraestructura

[**Guía de despliegue**](%F0%9F%9A%80%20DevOps%20CI%20CD%20Infraestructura%202069647e871080c1985af66ef23d8d4c/Gui%CC%81a%20de%20despliegue%202069647e8710805ca4faebcd03514fa3.md)

[**Configuración de entornos**](%F0%9F%9A%80%20DevOps%20CI%20CD%20Infraestructura%202069647e871080c1985af66ef23d8d4c/Configuracio%CC%81n%20de%20entornos%202069647e871080b3b38cfae3636d3833.md)

[**Variables de entorno**](%F0%9F%9A%80%20DevOps%20CI%20CD%20Infraestructura%202069647e871080c1985af66ef23d8d4c/Variables%20de%20entorno%202069647e8710808eb3e5f3f8413b250e.md)

[**Automatización y scripts**](%F0%9F%9A%80%20DevOps%20CI%20CD%20Infraestructura%202069647e871080c1985af66ef23d8d4c/Automatizacio%CC%81n%20y%20scripts%202069647e871080d589cee6c3cbdcb249.md)

[**Monitoreo y logs**](%F0%9F%9A%80%20DevOps%20CI%20CD%20Infraestructura%202069647e871080c1985af66ef23d8d4c/Monitoreo%20y%20logs%202069647e8710802faae9f0b2556af778.md)