# Stack tecnológico

- Lenguaje principal: TypeScript
- Framework backend: NestJS
- ORM: Prisma
- Base de datos: MySQL
- Autenticación: JWT
- Infraestructura: ( Azure, proximamente.)